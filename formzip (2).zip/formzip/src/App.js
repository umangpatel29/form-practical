import './App.css';
import FormMain from './Form/FormMain';
import TableData from './Form/Table';

function App() {
  return (
    <div className="App">
      <FormMain />
    </div>
  );
}

export default App;
